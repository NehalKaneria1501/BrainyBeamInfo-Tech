package com.example.utilityapp;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class DisplayActivity extends AppCompatActivity {
TextView displayData;
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_display);
    displayData = findViewById(R.id.displayData);
    SharedPreferences prefs = getSharedPreferences("signup_data", MODE_PRIVATE);
    String name = prefs.getString("name", "N/A");
    String email = prefs.getString("email", "N/A");
    String city = prefs.getString("city", "N/A");
    String gender = prefs.getString("gender", "N/A");
    String role = prefs.getString("role", "N/A");
    boolean accepted = prefs.getBoolean("accepted", false);
    String data = "Name: " + name +
                  "\nEmail: " + email +
                  "\nCity: " + city +
                  "\nGender: " + gender +
                  "\nRole: " + role +
                  "\nAccepted Terms: " + accepted;
    displayData.setText(data);
}
}
