package com.example.utilityapp;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.utilityapp.ui.share.ShareFragment;
import com.example.utilityapp.ui.videoplayer.VideoPlayerFragment;
import com.example.utilityapp.ui.watermark.WatermarkFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
public class HomeActivity extends AppCompatActivity {
SharedPreferences prefs;
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_home);
	androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
	setSupportActionBar(toolbar);
	prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
	BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);
	bottomNav.setOnItemSelectedListener(item -> {
		Fragment selectedFragment = null;
		if (item.getItemId() == R.id.nav_watermark) {
			selectedFragment = new WatermarkFragment();
		} else if (item.getItemId() == R.id.nav_video) {
			selectedFragment = new VideoPlayerFragment();
		} else if (item.getItemId() == R.id.nav_share) {
			selectedFragment = new ShareFragment();
		}
		if (selectedFragment != null) {
			getSupportFragmentManager().beginTransaction().replace(R.id.container, selectedFragment).commit();
			return true;
		}
		return false;
	});
	if (savedInstanceState == null) {
		bottomNav.setSelectedItemId(R.id.nav_watermark);
	}
}
@Override
public boolean onCreateOptionsMenu ( android.view.Menu menu ) {
	getMenuInflater().inflate ( com.example.utilityapp.R.menu.bottom_nav_menu, menu );
	return true;
}

@Override
public boolean onOptionsItemSelected(@NonNull MenuItem item) {
	if (item.getItemId() == R.id.action_logout) {
		prefs.edit().clear().apply();
		startActivity(new Intent(this, LoginActivity.class));
		finish();
		return true;
	}
	return super.onOptionsItemSelected(item);
}
}
