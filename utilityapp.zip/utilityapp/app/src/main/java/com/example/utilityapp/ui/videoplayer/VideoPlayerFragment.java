package com.example.utilityapp.ui.videoplayer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.Button;
import android.widget.VideoView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.utilityapp.R;
public class VideoPlayerFragment extends Fragment {
private static final String PREF_NAME = "VideoPrefs";
private static final String KEY_LAST_VIDEO_URI = "last_video_uri";
private VideoView videoView;
private Button btnSelectVideo;
private SharedPreferences sharedPreferences;
private final ActivityResultLauncher<Intent> videoPickerLauncher =
		registerForActivityResult(
				new ActivityResultContracts.StartActivityForResult(),
				result -> {
					if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
						Uri selectedVideoUri = result.getData().getData();
						if (selectedVideoUri != null) {
							playVideo(selectedVideoUri);
							saveVideoUriToPreferences(selectedVideoUri);
						}
						else {
							Toast.makeText(getContext(), "Video URI is null", Toast.LENGTH_SHORT).show();
						}
					} else {
						Toast.makeText(getContext(), "No video selected", Toast.LENGTH_SHORT).show();
					}
				});
@Nullable
@Override
public View onCreateView(@NonNull LayoutInflater inflater,
                         @Nullable ViewGroup container,
                         @Nullable Bundle savedInstanceState) {
	View v = inflater.inflate(R.layout.fragment_videoplayer, container, false);
	videoView = v.findViewById(R.id.videoView);
	btnSelectVideo = v.findViewById(R.id.btnSelectVideo);
	sharedPreferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
	btnSelectVideo.setOnClickListener(view -> {
		Intent intent = new Intent(Intent.ACTION_PICK);
		intent.setType("video/*");
		videoPickerLauncher.launch(intent);
	});
	String savedUri = sharedPreferences.getString(KEY_LAST_VIDEO_URI, null);
	if (savedUri != null) {
		Uri uri = Uri.parse(savedUri);
		playVideo(uri);
	}
	
	return v;
}

private void playVideo(Uri videoUri) {
	videoView.setVideoURI(videoUri);
	
	MediaController mediaController = new MediaController(requireContext());
	mediaController.setAnchorView(videoView);
	videoView.setMediaController(mediaController);
	
	videoView.setOnPreparedListener(mp -> {
		videoView.requestFocus();
		videoView.start();
	});
	
	videoView.setOnErrorListener((mp, what, extra) -> {
		Toast.makeText(getContext(), "Playback error. Try a different video.", Toast.LENGTH_LONG).show();
		return true;
	});
}

private void saveVideoUriToPreferences(Uri uri) {
	sharedPreferences.edit().putString(KEY_LAST_VIDEO_URI, uri.toString()).apply();
}
}
