package com.example.utilityapp.ui.share;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.example.utilityapp.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class ShareFragment extends Fragment {

private ImageView imageView;
private Button btnSelect, btnShare;
private Bitmap selectedImage;
private Uri imageUri;
private SharedPreferences sharedPreferences;
private final ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
		new ActivityResultContracts.StartActivityForResult(),
		result -> {
			if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
				try {
					Uri uri = result.getData().getData();
					selectedImage = MediaStore.Images.Media.getBitmap(requireActivity().getContentResolver(), uri);
					imageView.setImageBitmap(selectedImage);
					saveBitmapForSharing(selectedImage);
				} catch (Exception e) {
					e.printStackTrace();
					Toast.makeText(getContext(), "Failed to load image", Toast.LENGTH_SHORT).show();
				}
			}
		});
@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
	View v = inflater.inflate(R.layout.fragment_share, container, false);
	imageView = v.findViewById(R.id.imageView);
	btnSelect = v.findViewById(R.id.btnSelectImage);
	btnShare = v.findViewById(R.id.btnShareImage);
	sharedPreferences = requireActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
	loadSavedImage();
	btnSelect.setOnClickListener(view -> {
		Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		pickImageLauncher.launch(intent);
	});
	btnShare.setOnClickListener(view -> {
		if (imageUri != null) {
			shareImageExternally(imageUri);
		} else {
			Toast.makeText(getContext(), "Select an image first", Toast.LENGTH_SHORT).show();
		}
	});
	return v;
}
private void saveBitmapForSharing(Bitmap bitmap) {
	try {
		File cachePath = new File(requireContext().getCacheDir(), "images");
		if (!cachePath.exists()) {
			cachePath.mkdirs();
		}
		File file = new File(cachePath, "shared_image.jpg");
		OutputStream stream = new FileOutputStream(file);
		bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
		stream.flush();
		stream.close();
		imageUri = FileProvider.getUriForFile(requireContext(), requireContext().getPackageName() + ".provider", file);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString("image_path", file.getAbsolutePath());
		editor.apply();
	} catch (Exception e) {
		e.printStackTrace();
	}
}
private void loadSavedImage() {
	String path = sharedPreferences.getString("image_path", null);
	if (path != null) {
		File file = new File(path);
		if (file.exists()) {
			try {
				Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
				imageView.setImageBitmap(bitmap);
				selectedImage = bitmap;
				imageUri = FileProvider.getUriForFile(requireContext(), requireContext().getPackageName() + ".provider", file);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
private void shareImageExternally(Uri uri) {
	Intent shareIntent = new Intent(Intent.ACTION_SEND);
	shareIntent.setType("image/*");
	shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
	shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
	startActivity(Intent.createChooser(shareIntent, "Share Image using"));
}
}
