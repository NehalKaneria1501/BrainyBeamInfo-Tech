package com.example.utilityapp.ui.watermark;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.example.utilityapp.R;
import java.io.OutputStream;
public class WatermarkFragment extends Fragment {
private static final String PREF_NAME = "WatermarkPrefs";
private static final String KEY_LAST_IMAGE_URI = "last_image_uri";
private static final String KEY_WATERMARK_TEXT = "watermark_text";
ImageView imageView;
Button btnSelect, btnSave;
Bitmap selectedImage;
SharedPreferences sharedPreferences;
private final ActivityResultLauncher<String> requestPermissionLauncher =
		registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
			if (!isGranted) {
				Toast.makeText(getContext(), "Permission denied!", Toast.LENGTH_SHORT).show();
			}
		});
private final ActivityResultLauncher<Intent> pickImage =
		registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
			if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
				Uri uri = result.getData().getData();
				if (uri != null) {
					saveImageUriToPreferences(uri);
					loadAndDisplayImage(uri);
				}
			}
		});
@Nullable
@Override
public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
	View v = inflater.inflate(R.layout.fragment_watermark, container, false);
	imageView = v.findViewById(R.id.imageView);
	btnSelect = v.findViewById(R.id.btnSelect);
	btnSave = v.findViewById(R.id.btnSave);
	sharedPreferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
	checkPermissions();
	btnSelect.setOnClickListener(view -> {
		Intent pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		pickImage.launch(pick);
	});
	btnSave.setOnClickListener(view -> {
		if (selectedImage != null) {
			String watermarkText = "MyWatermark";
			saveWatermarkTextToPreferences(watermarkText);
			Bitmap bmp = addWatermark(selectedImage, watermarkText);
			saveImageToGallery(bmp);
		} else {
			Toast.makeText(getContext(), "Please select an image first", Toast.LENGTH_SHORT).show();
		}
	});
	String uriStr = sharedPreferences.getString(KEY_LAST_IMAGE_URI, null);
	if (uriStr != null) {
		loadAndDisplayImage(Uri.parse(uriStr));
	}
	return v;
}
private void checkPermissions() {
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
		if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
			requestPermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES);
		}
	} else {
		if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
			requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
		}
	}
}
private void loadAndDisplayImage(Uri uri) {
	try {
		selectedImage = MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), uri);
		imageView.setImageBitmap(selectedImage);
	} catch (Exception e) {
		e.printStackTrace();
		Toast.makeText(getContext(), "Failed to load image", Toast.LENGTH_SHORT).show();
	}
}
private Bitmap addWatermark(Bitmap src, String text) {
	Bitmap bmp = src.copy(Bitmap.Config.ARGB_8888, true);
	Canvas canvas = new Canvas(bmp);
	Paint paint = new Paint();
	paint.setColor(Color.RED);
	paint.setTextSize(60);
	paint.setAntiAlias(true);
	paint.setShadowLayer(5.0f, 10.0f, 10.0f, Color.BLACK);
	canvas.drawText(text, 50, bmp.getHeight() - 100, paint);
	return bmp;
}
private void saveImageToGallery(Bitmap bmp) {
	try {
		String fileName = "watermarked_" + System.currentTimeMillis() + ".jpg";
		ContentValues values = new ContentValues();
		values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
		values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
		values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UtilityApp");
		Uri uri = requireContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
		if (uri != null) {
			OutputStream stream = requireContext().getContentResolver().openOutputStream(uri);
			bmp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
			if (stream != null) {
				stream.flush();
				stream.close();
			}
			Toast.makeText(getContext(), "Image saved to gallery!", Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(getContext(), "Failed to create MediaStore entry", Toast.LENGTH_SHORT).show();
		}
	}
	catch (Exception e) {
		e.printStackTrace();
		Toast.makeText(getContext(), "Save Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
	}
}
private void saveImageUriToPreferences(Uri uri) {
	sharedPreferences.edit().putString(KEY_LAST_IMAGE_URI, uri.toString()).apply();
}
private void saveWatermarkTextToPreferences(String text) {
	sharedPreferences.edit().putString(KEY_WATERMARK_TEXT, text).apply();
}
}
