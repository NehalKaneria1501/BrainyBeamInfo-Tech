package com.example.utilityapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class LoginActivity extends AppCompatActivity {
EditText edtEmail, edtPassword;
Button btnLogin;
SharedPreferences prefs;
SharedPreferences.Editor editor;
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_login);
	prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
	editor = prefs.edit();
	if (prefs.getBoolean("isLoggedIn", false)) {
		startActivity(new Intent(this, HomeActivity.class));
		finish();
		return;
	}
	edtEmail = findViewById(R.id.edtEmail);
	edtPassword = findViewById(R.id.edtPassword);
	btnLogin = findViewById(R.id.btnLogin);
	btnLogin.setOnClickListener(v -> {
		String email = edtEmail.getText().toString().trim();
		String pass = edtPassword.getText().toString().trim();
		if (email.isEmpty() || pass.isEmpty()) {
			Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
			return;
		}
		if (email.equals("admin@example.com") && pass.equals("admin123")) {
			editor.putBoolean("isLoggedIn", true);
			editor.putString("email", email);
			editor.apply();
			startActivity(new Intent(this, HomeActivity.class));
			finish();
		}
		else {
			Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
		}
	});
}

}
