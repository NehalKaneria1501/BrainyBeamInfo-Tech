package com.example.utilityapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class SignupActivity extends AppCompatActivity {
EditText name, email;
AutoCompleteTextView ageAutoComplete;
Spinner stateSpinner;
RadioGroup genderRadioGroup;
CheckBox checkbox;
Button submit;
TextView loginLink;
String[] states = {
		"Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
		"Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
		"Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
		"Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
		"Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
		"Uttar Pradesh", "Uttarakhand", "West Bengal",
		"Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
		"Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
};
SharedPreferences prefs;
SharedPreferences.Editor editor;
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_signup);
	prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
	editor = prefs.edit();
	name = findViewById(R.id.name);
	email = findViewById(R.id.email);
	ageAutoComplete = findViewById(R.id.ageAutoComplete);
	stateSpinner = findViewById(R.id.stateSpinner);
	genderRadioGroup = findViewById(R.id.genderRadioGroup);
	checkbox = findViewById(R.id.checkbox);
	submit = findViewById(R.id.submit);
	loginLink = findViewById(R.id.loginLink);
	ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, states);
	stateSpinner.setAdapter(stateAdapter);
	String[] ages = new String[91];
	for (int i = 0; i <= 90; i++) {
		ages[i] = String.valueOf(i + 10);
	}
	ArrayAdapter<String> ageAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, ages);
	ageAutoComplete.setAdapter(ageAdapter);
	submit.setOnClickListener(view -> {
		String nameVal = name.getText().toString().trim();
		String emailVal = email.getText().toString().trim();
		String ageVal = ageAutoComplete.getText().toString().trim();
		String selectedState = stateSpinner.getSelectedItem().toString();
		if (nameVal.isEmpty()) {
			name.setError("Enter Name");
			return;
		}
		if (emailVal.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(emailVal).matches()) {
			email.setError("Enter Valid Email");
			return;
		}
		if (ageVal.isEmpty()) {
			ageAutoComplete.setError("Enter Age");
			return;
		}
		if (genderRadioGroup.getCheckedRadioButtonId() == -1) {
			Toast.makeText(this, "Select Gender", Toast.LENGTH_SHORT).show();
			return;
		}
		if (!checkbox.isChecked()) {
			Toast.makeText(this, "Please accept terms", Toast.LENGTH_SHORT).show();
			return;
		}
		
		RadioButton selectedGenderBtn = findViewById(genderRadioGroup.getCheckedRadioButtonId());
		String genderVal = selectedGenderBtn.getText().toString();
		editor.putString("name", nameVal);
		editor.putString("email", emailVal);
		editor.putString("age", ageVal);
		editor.putString("state", selectedState);
		editor.putString("gender", genderVal);
		editor.putBoolean("accepted", checkbox.isChecked());
		editor.apply();
		Toast.makeText(this, "Signup Successful!", Toast.LENGTH_SHORT).show();
		startActivity(new Intent(SignupActivity.this, LoginActivity.class));
		finish();
	});
	loginLink.setOnClickListener(v -> {
		startActivity(new Intent(SignupActivity.this, LoginActivity.class));
		finish();
	});
}
}
