package com.example.utilityapp;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
public class SplashActivity extends AppCompatActivity {
private static final int SPLASH_DELAY = 2000;
@Override
protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setTheme(R.style.Theme_Utilityapp);
	setContentView(R.layout.activity_splash);
	new Handler().postDelayed(() -> {
		SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
		String registeredEmail = prefs.getString("email", null);
		String registeredPassword = prefs.getString("password", null);
		boolean isLoggedIn = prefs.getBoolean("is_logged_in", false);
		if (registeredEmail == null || registeredPassword == null) {
			startActivity(new Intent(SplashActivity.this, SignupActivity.class));
		} else if (!isLoggedIn) {
			startActivity(new Intent(SplashActivity.this, LoginActivity.class));
		} else {
			startActivity(new Intent(SplashActivity.this, HomeActivity.class));
		}
		finish();
	}, SPLASH_DELAY);
}
}
